#ifndef __APP_VER_H_
#define __APP_VER_H_

#define APP_VERSION_MAJOR 0
#define APP_VERSION_MINOR 4
#define APP_VERSION_PATCH 1
#define APP_VERSION_BUILD 0

#endif
