#ifndef __TOKEN_H_
#define __TOKEN_H_

#include <stdint.h>

#include "token_macros.h"
#include "token_config.h"

void     TOKEN_init     (void);

/*
   uint8_t  TOKEN_getU8    ( uint32_t token );
   uint16_t TOKEN_getU16   ( uint32_t token );
   uint32_t TOKEN_get32    ( uint32_t token );
   uint16_t TOKEN_getCount ( void );
 */

#endif
