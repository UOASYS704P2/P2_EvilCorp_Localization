#ifndef __TBSENSE_GATT_SERVICE_POWER_H_
#define __TBSENSE_GATT_SERVICE_POWER_H_

#include "bg_types.h"

void powerInit(void);
void powerDeInit(void);
void powerSourceTypeRead(void);

#endif
